package com.stucom.franmorenoalc;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class AdjustmentsActivity extends AppCompatActivity {

    //variables para recoger imágenes de la camara. Se ha descartado por errores de última hora.
    // static final int REQUEST_IMAGE_CAPTURE = 1;
    //String mCurrentPhotoPath;


    EditText editName;    // editText para el nombre
    EditText editMail;    // editText para el mail
    Button myDialog;    //button para un pequeño Dialog box emergente al clickar Options
    ImageView photo;  //ImageView para colocar la fotografía de perfil


    //variables para el AlertDialog
    Button gallery, camera, delete;


    /* En el onCreate, fijamos los widgets de la Activity, como los EditTexts de nombre y mail,
         * la imagen de perfil y el boton para el AlertDialog donde se muestran tres botones con las diferentes
          * opciones para gestionar la fotografía del perfil. Estas funcionalidades de imagen (subir foto de
          * la galería, obtener una foto de la cámara o eliminar la foto de perfil no han sido implementadas,
          * con lo cual de momento solo hemos conseguido desplegar el AlertDialog con los botones.*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adjustments);
        editName = findViewById(R.id.yourName);
        editMail = findViewById(R.id.yourMail);
        photo = findViewById(R.id.yourPhoto);
        myDialog =  findViewById(R.id.uploadImage);
        myDialog.setOnClickListener(new View.OnClickListener() {
            /* Al hacer click en el boton opciones (lo llamamos myDialog) se genera un AlertDialog  */
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(AdjustmentsActivity.this);
                @SuppressLint("InflateParams") View mView = getLayoutInflater().inflate(R.layout.activity_dialog, null);
                //fijamos los buttons
                gallery = findViewById(R.id.uploadImage);
                camera = findViewById(R.id.buttonCam);
                delete = findViewById(R.id.buttonDelete);

                mBuilder.setView(mView);
                final AlertDialog dialog = mBuilder.create();
                dialog.show();
            }
        });
    }

    /* Cuando la Activity entra al estado onResume declaramos el objeto SharedPreferences y obtenemos
       * los campos nombre y mail que habiamos guardado en onPause(), a continuación los fijamos de
        * nuevo en los editText.*/
    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences prefs = getSharedPreferences(getPackageName(), MODE_PRIVATE);
        String name = prefs.getString("name", "");
        String mail = prefs.getString("mail", "");

        editName.setText(name);
        editMail.setText(mail);
    }

   /* Cuando la Activity entra en un estado onPause, realizamos las acciones necesarias para
     * conseguir que los datos nombre y mail introducidos queden preservados.  */
    @Override
    public void onPause() {
        String name = editName.getText().toString();
        String mail = editMail.getText().toString();
        SharedPreferences prefs = getSharedPreferences(getPackageName(), MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        ed.putString("name", name);
        ed.putString("mail", mail);
        ed.apply();
        super.onPause();
    }

}








